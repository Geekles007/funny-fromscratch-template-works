$(function(){
    $('.left-block').addClass('animated bounceInLeft')
    $('.right-block').addClass('animated bounceInUp')

});